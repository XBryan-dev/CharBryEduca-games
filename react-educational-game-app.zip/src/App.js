import React from 'react';
function App() { return (<div>Welcome to EduGame</div>); }
export default App;